/**
 * AAVAAZ Clinical — Client Application
 *
 * Pipeline (mirrors server architecture):
 *   Mic → VAD (browser) → ASR (Web Speech API) → WebSocket → Server → Translation Worker → WebSocket → TTS (SpeechSynthesis)
 *
 * Threading (browser context):
 *   Main thread:    UI updates, WebSocket, orchestration
 *   ASR:            Runs in browser's speech recognition thread (off main thread)
 *   TTS:            Runs in browser's synthesis thread (off main thread)
 *   AudioWorklet:   Audio level metering (off main thread)
 */

// ─── State ───

const state = {
  role: null,
  lang: null,
  targetLang: null,
  peerRole: null,
  ws: null,
  recognition: null,
  isListening: false,
  isTTSEnabled: true,
  isAutoMode: false,
  peerConnected: false,
  sessionStart: null,
  messages: [],
  audioContext: null,
  analyser: null,
  micStream: null,
  reconnectAttempts: 0,
  maxReconnectAttempts: 20,
  reconnectDelay: 1000,
};

// ─── Initialization ───

async function init() {
  // Detect role from port
  const port = parseInt(window.location.port);
  if (port === 3000) {
    state.role = 'doctor';
    state.lang = 'en-US';
    state.targetLang = 'es';
    state.peerRole = 'patient';
  } else if (port === 3001) {
    state.role = 'patient';
    state.lang = 'es-ES';
    state.targetLang = 'en';
    state.peerRole = 'doctor';
  } else {
    showToast('Unknown port. Use localhost:3000 (Doctor) or localhost:3001 (Patient)', 'error');
    return;
  }

  // Apply role class
  document.body.classList.add(`role-${state.role}`);

  // Update UI
  document.getElementById('role-label').textContent = state.role === 'doctor' ? 'Doctor' : 'Paciente';
  document.getElementById('lang-badge').textContent = state.role === 'doctor' ? 'EN' : 'ES';
  document.getElementById('target-lang-badge').textContent = state.role === 'doctor' ? 'ES' : 'EN';
  document.title = `AAVAAZ — ${state.role === 'doctor' ? 'Doctor (EN)' : 'Paciente (ES)'}`;

  // Init subsystems
  initWebSocket();
  initSpeechRecognition();
  initAudioMeter();
  initControls();
  startSessionTimer();

  console.log(`[AAVAAZ] Initialized as ${state.role} (${state.lang})`);
}

// ─── WebSocket ───

function initWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const url = `${protocol}//${window.location.host}`;

  state.ws = new WebSocket(url);

  state.ws.onopen = () => {
    console.log('[WS] Connected');
    state.reconnectAttempts = 0;
    state.reconnectDelay = 1000;
    updateConnectionStatus('connected');

    // Notify server
    state.ws.send(JSON.stringify({
      type: 'status',
      status: 'connected',
    }));
  };

  state.ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    handleServerMessage(msg);
  };

  state.ws.onclose = () => {
    console.log('[WS] Disconnected');
    updateConnectionStatus('disconnected');
    attemptReconnect();
  };

  state.ws.onerror = (err) => {
    console.error('[WS] Error:', err);
  };
}

function attemptReconnect() {
  if (state.reconnectAttempts >= state.maxReconnectAttempts) {
    showToast('Connection lost. Please refresh the page.', 'error');
    return;
  }

  state.reconnectAttempts++;
  const delay = Math.min(state.reconnectDelay * Math.pow(1.5, state.reconnectAttempts - 1), 10000);

  console.log(`[WS] Reconnecting in ${Math.round(delay)}ms (attempt ${state.reconnectAttempts})`);

  setTimeout(() => {
    if (!state.ws || state.ws.readyState === WebSocket.CLOSED) {
      initWebSocket();
    }
  }, delay);
}

function sendToServer(msg) {
  if (state.ws && state.ws.readyState === WebSocket.OPEN) {
    state.ws.send(JSON.stringify(msg));
  }
}

// ─── Handle Server Messages ───

function handleServerMessage(msg) {
  switch (msg.type) {
    case 'welcome':
      console.log(`[Server] Welcome: ${msg.role} (${msg.lang} → ${msg.targetLang})`);
      break;

    case 'peer_status':
      state.peerConnected = msg.status === 'connected';
      updatePeerStatus(msg.role, msg.status);
      break;

    case 'message':
      // Message from the OTHER party (translated for us)
      addMessage({
        from: msg.from,
        original: msg.original,
        translated: msg.translated,
        sourceLang: msg.sourceLang,
        targetLang: msg.targetLang,
        latencyMs: msg.translationLatencyMs,
        timestamp: msg.timestamp,
        isSelf: false,
      });

      // Speak the translated text (which is in OUR language)
      if (state.isTTSEnabled) {
        speak(msg.translated, state.lang);
      }
      break;

    case 'self_message':
      // Echo of our own message with translation
      addMessage({
        from: msg.from,
        original: msg.original,
        translated: msg.translated,
        sourceLang: msg.sourceLang,
        targetLang: msg.targetLang,
        latencyMs: msg.translationLatencyMs,
        timestamp: msg.timestamp,
        isSelf: true,
      });
      break;

    case 'interim_transcript':
      // Live typing from peer
      showInterimTranscript(msg.text, msg.from);
      break;

    case 'error':
      showToast(msg.message, 'error');
      break;
  }
}

// ─── Speech Recognition (ASR) ───

function initSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    showToast('Speech recognition not supported. Use Chrome.', 'error');
    return;
  }

  state.recognition = new SpeechRecognition();
  state.recognition.lang = state.lang;
  state.recognition.continuous = true;
  state.recognition.interimResults = true;
  state.recognition.maxAlternatives = 1;

  state.recognition.onresult = (event) => {
    let interimTranscript = '';
    let finalTranscript = '';

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i];
      if (result.isFinal) {
        finalTranscript += result[0].transcript;
      } else {
        interimTranscript += result[0].transcript;
      }
    }

    // Send interim results for live preview on peer's side
    if (interimTranscript) {
      sendToServer({
        type: 'transcript',
        text: interimTranscript,
        isFinal: false,
      });
      showSelfInterim(interimTranscript);
    }

    // Send final transcript for translation
    if (finalTranscript) {
      sendToServer({
        type: 'transcript',
        text: finalTranscript,
        isFinal: true,
      });
      clearInterim();
    }
  };

  state.recognition.onerror = (event) => {
    // 'no-speech' and 'aborted' are normal — don't show errors for these
    if (event.error === 'no-speech' || event.error === 'aborted') {
      return;
    }
    console.error('[ASR] Error:', event.error);

    if (event.error === 'not-allowed') {
      showToast('Microphone access denied. Please allow microphone permission.', 'error');
      stopListening();
    }
  };

  state.recognition.onend = () => {
    // Auto-restart if still in listening mode (browser stops after silence)
    if (state.isListening) {
      try {
        state.recognition.start();
      } catch (e) {
        // Already started, ignore
      }
    }
  };
}

function startListening() {
  if (!state.recognition) return;

  try {
    state.recognition.start();
    state.isListening = true;
    updateMicButton(true);
    updateConnectionStatus('listening');
  } catch (e) {
    // Already started
    if (e.name === 'InvalidStateError') {
      state.isListening = true;
      updateMicButton(true);
    }
  }
}

function stopListening() {
  if (!state.recognition) return;

  try {
    state.recognition.stop();
  } catch (e) {
    // Not started, ignore
  }
  state.isListening = false;
  updateMicButton(false);
  updateConnectionStatus(state.peerConnected ? 'connected' : 'disconnected');
  clearInterim();
}

function toggleListening() {
  if (state.isListening) {
    stopListening();
  } else {
    startListening();
  }
}

// ─── Text-to-Speech (TTS) ───

let ttsQueue = [];
let isSpeaking = false;

function speak(text, lang) {
  if (!window.speechSynthesis || !text) return;

  ttsQueue.push({ text, lang });
  if (!isSpeaking) {
    processNextTTS();
  }
}

function processNextTTS() {
  if (ttsQueue.length === 0) {
    isSpeaking = false;
    // Restart ASR after all queued speech finishes
    if (state.isListening && state.recognition) {
      setTimeout(() => {
        if (state.isListening) {
          try { state.recognition.start(); } catch (e) { /* ignore */ }
        }
      }, 200);
    }
    return;
  }

  isSpeaking = true;
  const { text, lang } = ttsQueue.shift();

  // Pause ASR while speaking (avoid echo)
  if (state.isListening && state.recognition) {
    try { state.recognition.stop(); } catch (e) { /* ignore */ }
  }

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang;
  utterance.rate = 1.15; // Faster for real-time feel
  utterance.pitch = 1.0;
  utterance.volume = 1.0;

  // Try to find a good voice for the language
  const voices = window.speechSynthesis.getVoices();
  const langPrefix = lang.split('-')[0];
  const match = voices.find(v => v.lang.startsWith(langPrefix) && v.localService) ||
                voices.find(v => v.lang.startsWith(langPrefix));
  if (match) {
    utterance.voice = match;
  }

  utterance.onend = () => processNextTTS();
  utterance.onerror = () => processNextTTS();

  window.speechSynthesis.speak(utterance);
}

// Pre-load voices (Chrome loads them async)
if (window.speechSynthesis) {
  window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    window.speechSynthesis.getVoices();
  };
}

// ─── Audio Level Meter ───

async function initAudioMeter() {
  try {
    state.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    state.analyser = state.audioContext.createAnalyser();
    state.analyser.fftSize = 256;
    state.analyser.smoothingTimeConstant = 0.8;

    const source = state.audioContext.createMediaStreamSource(state.micStream);
    source.connect(state.analyser);

    // Start animation loop
    updateAudioLevel();
  } catch (err) {
    console.warn('[Audio] Mic access for level meter failed:', err.message);
  }
}

function updateAudioLevel() {
  if (!state.analyser) return;

  const data = new Uint8Array(state.analyser.frequencyBinCount);
  state.analyser.getByteFrequencyData(data);

  const bars = document.querySelectorAll('.audio-bar');
  if (bars.length === 0) {
    requestAnimationFrame(updateAudioLevel);
    return;
  }

  // Sample bars from frequency data
  const step = Math.floor(data.length / bars.length);
  bars.forEach((bar, i) => {
    const value = state.isListening ? data[i * step] : 0;
    const height = Math.max(3, (value / 255) * 32);
    bar.style.height = `${height}px`;
  });

  requestAnimationFrame(updateAudioLevel);
}

// ─── UI Updates ───

function addMessage({ from, original, translated, sourceLang, targetLang, latencyMs, timestamp, isSelf }) {
  const container = document.getElementById('transcript-container');
  const emptyState = document.getElementById('empty-state');

  if (emptyState) emptyState.remove();

  // Clear interim indicator
  clearPeerInterim();

  const msgEl = document.createElement('div');
  msgEl.className = `message ${isSelf ? 'self' : 'peer'}`;

  const time = new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const roleLabel = from === 'doctor' ? 'Doctor' : 'Paciente';
  const latencyStr = latencyMs ? `${latencyMs}ms` : '';

  // Only show the language this user understands
  // Self messages: show original (what you said in your language)
  // Peer messages: show translated (what they said, translated to your language)
  const displayText = isSelf ? original : translated;

  msgEl.innerHTML = `
    <div class="message-header">
      <span class="message-role ${from}">${roleLabel}</span>
      <span class="message-time">${time}</span>
      ${latencyStr ? `<span class="message-latency">${latencyStr}</span>` : ''}
    </div>
    <div class="message-bubble">
      <div class="message-original">${escapeHtml(displayText)}</div>
    </div>
  `;

  container.appendChild(msgEl);
  container.scrollTop = container.scrollHeight;

  // Store message
  state.messages.push({ from, original, translated, timestamp, isSelf });
}

function showInterimTranscript(text, from) {
  const el = document.getElementById('peer-interim');
  if (!el) return;

  const label = from === 'doctor' ? 'Doctor' : 'Paciente';
  el.innerHTML = `
    <div class="interim-label">${label} speaking...</div>
    <div class="interim-text">${escapeHtml(text)}</div>
  `;
  el.style.display = 'block';
}

function showSelfInterim(text) {
  const el = document.getElementById('self-interim');
  if (!el) return;
  el.innerHTML = `<div class="interim-text">${escapeHtml(text)}</div>`;
  el.style.display = 'block';
}

function clearInterim() {
  const el = document.getElementById('self-interim');
  if (el) { el.style.display = 'none'; el.innerHTML = ''; }
}

function clearPeerInterim() {
  const el = document.getElementById('peer-interim');
  if (el) { el.style.display = 'none'; el.innerHTML = ''; }
}

function updateMicButton(active) {
  const btn = document.getElementById('mic-button');
  const label = document.getElementById('mic-label');
  if (!btn) return;

  btn.classList.toggle('active', active);

  if (active) {
    btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2c0 .76-.12 1.5-.35 2.18"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`;
    label.textContent = state.role === 'doctor' ? 'Stop (listening...)' : 'Detener (escuchando...)';
  } else {
    btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`;
    label.textContent = state.role === 'doctor' ? 'Press to speak' : 'Presione para hablar';
  }
}

function updateConnectionStatus(status) {
  const dot = document.getElementById('connection-dot');
  const text = document.getElementById('connection-text');
  if (!dot) return;

  dot.className = `status-dot ${status}`;
  const labels = {
    connected: 'Connected',
    disconnected: 'Disconnected',
    listening: 'Listening',
  };
  text.textContent = labels[status] || status;
}

function updatePeerStatus(role, status) {
  const dot = document.getElementById('peer-dot');
  const text = document.getElementById('peer-text');
  if (!dot) return;

  dot.className = `status-dot ${status}`;
  const roleLabel = role === 'doctor' ? 'Doctor' : 'Patient';
  text.textContent = status === 'connected' ? `${roleLabel} online` : `${roleLabel} offline`;

  if (status === 'connected') {
    showToast(`${roleLabel} has joined the session`, 'success');
  } else {
    showToast(`${roleLabel} has left the session`, 'info');
  }
}

function startSessionTimer() {
  state.sessionStart = Date.now();
  const timerEl = document.getElementById('session-timer');

  setInterval(() => {
    const elapsed = Date.now() - state.sessionStart;
    const mins = Math.floor(elapsed / 60000);
    const secs = Math.floor((elapsed % 60000) / 1000);
    timerEl.textContent = `${mins}:${secs.toString().padStart(2, '0')}`;
  }, 1000);
}

// ─── Controls ───

function initControls() {
  // Mic button
  document.getElementById('mic-button').addEventListener('click', toggleListening);

  // TTS toggle
  document.getElementById('tts-toggle').addEventListener('click', () => {
    state.isTTSEnabled = !state.isTTSEnabled;
    document.getElementById('tts-toggle').classList.toggle('active', state.isTTSEnabled);
    document.getElementById('tts-toggle').textContent = state.isTTSEnabled
      ? (state.role === 'doctor' ? 'Sound ON' : 'Sonido ON')
      : (state.role === 'doctor' ? 'Sound OFF' : 'Sonido OFF');
  });

  // Auto mode toggle
  document.getElementById('auto-toggle').addEventListener('click', () => {
    state.isAutoMode = !state.isAutoMode;
    document.getElementById('auto-toggle').classList.toggle('active', state.isAutoMode);

    if (state.isAutoMode) {
      startListening();
      document.getElementById('auto-toggle').textContent = state.role === 'doctor' ? 'Auto ON' : 'Auto ON';
    } else {
      document.getElementById('auto-toggle').textContent = state.role === 'doctor' ? 'Auto OFF' : 'Auto OFF';
    }
  });

  // Keyboard shortcut: Space to toggle mic
  document.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
      e.preventDefault();
      toggleListening();
    }
  });

  // Initialize button states
  updateMicButton(false);
  document.getElementById('tts-toggle').classList.add('active');
}

// ─── Toast Notifications ───

function showToast(message, type = 'info') {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ─── Utilities ───

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ─── Boot ───

document.addEventListener('DOMContentLoaded', init);
