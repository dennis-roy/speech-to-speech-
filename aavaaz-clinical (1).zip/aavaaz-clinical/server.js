/**
 * AAVAAZ Clinical Translation Server
 *
 * Architecture:
 *   - Port 3000: Doctor frontend (English)
 *   - Port 3001: Patient frontend (Spanish)
 *   - WebSocket on each port for real-time bidirectional relay
 *   - Worker thread pool for translation (off main event loop)
 *   - Message pipeline: ASR transcript → Worker translate → Relay to other party
 *
 * Threading model:
 *   Main thread:  WebSocket relay, HTTP serving, orchestration
 *   Worker 1-N:   Translation inference (parallel, non-blocking)
 */

const express = require('express');
const http = require('http');
const { WebSocketServer, WebSocket } = require('ws');
const { Worker } = require('worker_threads');
const path = require('path');
const os = require('os');

// ─── Configuration ───

const CONFIG = {
  doctorPort: 3000,
  patientPort: 3001,
  doctorLang: 'en',
  patientLang: 'es',
  // Worker pool size: use available CPU cores (min 2, max 4)
  workerPoolSize: Math.min(4, Math.max(2, os.cpus().length - 1)),
  // Heartbeat interval (ms)
  heartbeatInterval: 10000,
  // Max message queue depth per client
  maxQueueDepth: 100,
};

console.log(`[Server] Starting with ${CONFIG.workerPoolSize} translation workers`);

// ─── Translation Worker Pool ───

class TranslationWorkerPool {
  constructor(size) {
    this.workers = [];
    this.pending = new Map(); // id → { resolve, reject, timer }
    this.nextId = 0;
    this.roundRobin = 0;

    for (let i = 0; i < size; i++) {
      const worker = new Worker(path.join(__dirname, 'translation-worker.js'));

      worker.on('message', (msg) => {
        if (msg.type === 'translation_result') {
          const entry = this.pending.get(msg.id);
          if (entry) {
            clearTimeout(entry.timer);
            this.pending.delete(msg.id);
            entry.resolve(msg);
          }
        }
        if (msg.type === 'prewarm_done') {
          console.log(`[Worker ${i}] Pre-warmed`);
        }
      });

      worker.on('error', (err) => {
        console.error(`[Worker ${i}] Error:`, err.message);
      });

      this.workers.push(worker);
    }
  }

  /**
   * Pre-warm all workers (init connections, JIT, etc.)
   */
  prewarm() {
    this.workers.forEach((w) => w.postMessage({ type: 'prewarm' }));
  }

  /**
   * Submit translation job to next available worker.
   * Returns promise that resolves with translation result.
   */
  translate(text, sourceLang, targetLang, fromRole) {
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const workerIdx = this.roundRobin % this.workers.length;
      this.roundRobin++;

      // Timeout: reject if translation takes >5s
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('Translation timeout'));
      }, 5000);

      this.pending.set(id, { resolve, reject, timer });

      this.workers[workerIdx].postMessage({
        type: 'translate',
        id,
        text,
        sourceLang,
        targetLang,
        fromRole,
      });
    });
  }

  shutdown() {
    this.workers.forEach((w) => w.terminate());
    for (const [id, entry] of this.pending) {
      clearTimeout(entry.timer);
      entry.reject(new Error('Pool shutdown'));
    }
    this.pending.clear();
  }
}

// ─── Create Worker Pool ───

const pool = new TranslationWorkerPool(CONFIG.workerPoolSize);
pool.prewarm();

// ─── Client State ───

let doctorWs = null;
let patientWs = null;
let sessionStartTime = null;

function getSessionDuration() {
  if (!sessionStartTime) return '0:00';
  const secs = Math.floor((Date.now() - sessionStartTime) / 1000);
  const mins = Math.floor(secs / 60);
  const s = secs % 60;
  return `${mins}:${s.toString().padStart(2, '0')}`;
}

// ─── WebSocket Message Handler ───

async function handleMessage(data, fromRole) {
  let msg;
  try {
    msg = JSON.parse(data);
  } catch {
    return;
  }

  const targetWs = fromRole === 'doctor' ? patientWs : doctorWs;
  const sourceLang = fromRole === 'doctor' ? CONFIG.doctorLang : CONFIG.patientLang;
  const targetLang = fromRole === 'doctor' ? CONFIG.patientLang : CONFIG.doctorLang;

  switch (msg.type) {
    case 'transcript': {
      // Translate interim transcripts too — peer sees translated text live
      if (!msg.isFinal) {
        if (targetWs && targetWs.readyState === WebSocket.OPEN) {
          // Fire-and-forget translation for interim (don't block, don't fail hard)
          pool.translate(msg.text, sourceLang, targetLang, fromRole)
            .then((result) => {
              if (targetWs && targetWs.readyState === WebSocket.OPEN) {
                targetWs.send(JSON.stringify({
                  type: 'interim_transcript',
                  text: result.translated,
                  from: fromRole,
                  lang: targetLang,
                }));
              }
            })
            .catch(() => {
              // Fallback: send untranslated
              if (targetWs && targetWs.readyState === WebSocket.OPEN) {
                targetWs.send(JSON.stringify({
                  type: 'interim_transcript',
                  text: msg.text,
                  from: fromRole,
                  lang: sourceLang,
                }));
              }
            });
        }
        return;
      }

      // Final transcript → translate via worker pool, then relay
      const timestamp = Date.now();

      try {
        const result = await pool.translate(msg.text, sourceLang, targetLang, fromRole);

        const outgoing = {
          type: 'message',
          original: result.original,
          translated: result.translated,
          from: fromRole,
          sourceLang: result.sourceLang,
          targetLang: result.targetLang,
          translationLatencyMs: result.latencyMs,
          timestamp,
          sessionDuration: getSessionDuration(),
        };

        // Send to OTHER party (translated version for them to hear/read)
        if (targetWs && targetWs.readyState === WebSocket.OPEN) {
          targetWs.send(JSON.stringify(outgoing));
        }

        // Echo back to SENDER (confirmation of what they said)
        const senderWs = fromRole === 'doctor' ? doctorWs : patientWs;
        if (senderWs && senderWs.readyState === WebSocket.OPEN) {
          senderWs.send(JSON.stringify({
            type: 'self_message',
            original: result.original,
            translated: result.translated,
            from: fromRole,
            sourceLang: result.sourceLang,
            targetLang: result.targetLang,
            translationLatencyMs: result.latencyMs,
            timestamp,
            sessionDuration: getSessionDuration(),
          }));
        }
      } catch (err) {
        console.error(`[Server] Translation failed: ${err.message}`);
        // Send error to sender
        const senderWs = fromRole === 'doctor' ? doctorWs : patientWs;
        if (senderWs && senderWs.readyState === WebSocket.OPEN) {
          senderWs.send(JSON.stringify({
            type: 'error',
            message: 'Translation failed. Please repeat.',
          }));
        }
      }
      break;
    }

    case 'status': {
      // Notify the other party about connection status
      if (targetWs && targetWs.readyState === WebSocket.OPEN) {
        targetWs.send(JSON.stringify({
          type: 'peer_status',
          role: fromRole,
          status: msg.status,
        }));
      }
      break;
    }
  }
}

// ─── Create Express Apps & Servers ───

function createServer(port, role) {
  const app = express();
  app.use(express.static(path.join(__dirname, 'public')));

  // Serve role-specific HTML
  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', `${role}.html`));
  });

  // Config endpoint — client fetches role/lang info
  app.get('/config', (req, res) => {
    res.json({
      role,
      lang: role === 'doctor' ? CONFIG.doctorLang : CONFIG.patientLang,
      targetLang: role === 'doctor' ? CONFIG.patientLang : CONFIG.doctorLang,
      peerRole: role === 'doctor' ? 'patient' : 'doctor',
    });
  });

  // Health check
  app.get('/health', (req, res) => {
    res.json({
      status: 'ok',
      role,
      peerConnected: role === 'doctor'
        ? patientWs?.readyState === WebSocket.OPEN
        : doctorWs?.readyState === WebSocket.OPEN,
      sessionDuration: getSessionDuration(),
      workers: CONFIG.workerPoolSize,
    });
  });

  const server = http.createServer(app);

  // WebSocket server
  const wss = new WebSocketServer({ server });

  wss.on('connection', (ws) => {
    console.log(`[${role.toUpperCase()}] Connected on port ${port}`);

    // Store reference
    if (role === 'doctor') {
      doctorWs = ws;
    } else {
      patientWs = ws;
    }

    // Start session timer on first connection
    if (!sessionStartTime) {
      sessionStartTime = Date.now();
    }

    // Notify peer
    const peerWs = role === 'doctor' ? patientWs : doctorWs;
    if (peerWs && peerWs.readyState === WebSocket.OPEN) {
      peerWs.send(JSON.stringify({
        type: 'peer_status',
        role,
        status: 'connected',
      }));
      // Also tell the new client that peer is already connected
      ws.send(JSON.stringify({
        type: 'peer_status',
        role: role === 'doctor' ? 'patient' : 'doctor',
        status: 'connected',
      }));
    }

    // Send welcome
    ws.send(JSON.stringify({
      type: 'welcome',
      role,
      lang: role === 'doctor' ? CONFIG.doctorLang : CONFIG.patientLang,
      targetLang: role === 'doctor' ? CONFIG.patientLang : CONFIG.doctorLang,
    }));

    // Handle incoming messages
    ws.on('message', (data) => {
      handleMessage(data.toString(), role);
    });

    // Heartbeat
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });

    // Disconnect
    ws.on('close', () => {
      console.log(`[${role.toUpperCase()}] Disconnected`);
      if (role === 'doctor') doctorWs = null;
      else patientWs = null;

      // Notify peer
      const peer = role === 'doctor' ? patientWs : doctorWs;
      if (peer && peer.readyState === WebSocket.OPEN) {
        peer.send(JSON.stringify({
          type: 'peer_status',
          role,
          status: 'disconnected',
        }));
      }

      // Reset session if both disconnected
      if (!doctorWs && !patientWs) {
        sessionStartTime = null;
      }
    });

    ws.on('error', (err) => {
      console.error(`[${role.toUpperCase()}] WebSocket error:`, err.message);
    });
  });

  // Heartbeat check — detect dead connections
  const heartbeat = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (!ws.isAlive) {
        console.log(`[${role.toUpperCase()}] Heartbeat failed, terminating`);
        return ws.terminate();
      }
      ws.isAlive = false;
      ws.ping();
    });
  }, CONFIG.heartbeatInterval);

  wss.on('close', () => clearInterval(heartbeat));

  server.listen(port, () => {
    console.log(`[${role.toUpperCase()}] http://localhost:${port}`);
  });

  return server;
}

// ─── Launch Both Servers ───

const doctorServer = createServer(CONFIG.doctorPort, 'doctor');
const patientServer = createServer(CONFIG.patientPort, 'patient');

console.log('\n  AAVAAZ Clinical Translation');
console.log('  ──────────────────────────────');
console.log(`  Doctor  (EN) → http://localhost:${CONFIG.doctorPort}`);
console.log(`  Patient (ES) → http://localhost:${CONFIG.patientPort}`);
console.log(`  Workers: ${CONFIG.workerPoolSize} threads`);
console.log('  ──────────────────────────────\n');

// ─── Graceful Shutdown ───

function shutdown() {
  console.log('\n[Server] Shutting down...');
  pool.shutdown();
  doctorServer.close();
  patientServer.close();
  process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
