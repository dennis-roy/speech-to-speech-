/**
 * Translation Worker Thread
 * Runs translation off the main event loop — keeps WebSocket relay non-blocking.
 * In production: replace HTTP API call with local NLLB/MarianMT model inference.
 */
const { parentPort, workerData } = require('worker_threads');

const TRANSLATION_CACHE = new Map();
const CACHE_MAX = 2000;

// Clinical glossary — medical terms that should be transliterated, not translated
const CLINICAL_GLOSSARY = {
  'en-es': {
    'metformin': 'metformina',
    'ibuprofen': 'ibuprofeno',
    'acetaminophen': 'acetaminofén',
    'amoxicillin': 'amoxicilina',
    'omeprazole': 'omeprazol',
    'lisinopril': 'lisinopril',
    'atorvastatin': 'atorvastatina',
    'amlodipine': 'amlodipino',
    'hydrochlorothiazide': 'hidroclorotiazida',
    'levothyroxine': 'levotiroxina',
    'prednisone': 'prednisona',
    'albuterol': 'albuterol',
    'insulin': 'insulina',
    'aspirin': 'aspirina',
    'warfarin': 'warfarina',
    'morphine': 'morfina',
    'penicillin': 'penicilina',
    'MRI': 'resonancia magnética',
    'CT scan': 'tomografía computarizada',
    'EKG': 'electrocardiograma',
    'ECG': 'electrocardiograma',
    'IV': 'intravenoso',
    'BP': 'presión arterial',
    'HR': 'frecuencia cardíaca',
  },
  'es-en': {
    'metformina': 'metformin',
    'ibuprofeno': 'ibuprofen',
    'acetaminofén': 'acetaminophen',
    'amoxicilina': 'amoxicillin',
    'omeprazol': 'omeprazole',
    'lisinopril': 'lisinopril',
    'atorvastatina': 'atorvastatin',
    'amlodipino': 'amlodipine',
    'hidroclorotiazida': 'hydrochlorothiazide',
    'levotiroxina': 'levothyroxine',
    'prednisona': 'prednisone',
    'albuterol': 'albuterol',
    'insulina': 'insulin',
    'aspirina': 'aspirin',
    'warfarina': 'warfarin',
    'morfina': 'morphine',
    'penicilina': 'penicillin',
    'resonancia magnética': 'MRI',
    'tomografía computarizada': 'CT scan',
    'electrocardiograma': 'EKG',
    'intravenoso': 'IV',
    'presión arterial': 'blood pressure',
    'frecuencia cardíaca': 'heart rate',
  }
};

/**
 * Apply clinical glossary replacements before translation
 */
function applyGlossary(text, langPair) {
  const glossary = CLINICAL_GLOSSARY[langPair];
  if (!glossary) return text;

  let result = text;
  for (const [term, replacement] of Object.entries(glossary)) {
    const regex = new RegExp(`\\b${term}\\b`, 'gi');
    result = result.replace(regex, `__GLOSS_${replacement}__`);
  }
  return result;
}

/**
 * Restore glossary terms after translation
 */
function restoreGlossary(text) {
  return text.replace(/__GLOSS_(.+?)__/g, '$1');
}

/**
 * Translate text using MyMemory API (free, no key needed)
 * Production: replace with local NLLB-200 / MarianMT inference
 */
async function translateText(text, sourceLang, targetLang) {
  if (!text || !text.trim()) return '';

  const langPair = `${sourceLang}-${targetLang}`;
  const cacheKey = `${langPair}:${text.toLowerCase().trim()}`;

  // Check cache first
  if (TRANSLATION_CACHE.has(cacheKey)) {
    return TRANSLATION_CACHE.get(cacheKey);
  }

  // Apply clinical glossary
  const glossaryApplied = applyGlossary(text, langPair);

  // Map language codes for API
  const langMap = { en: 'en', es: 'es' };
  const from = langMap[sourceLang] || sourceLang;
  const to = langMap[targetLang] || targetLang;

  try {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(glossaryApplied)}&langpair=${from}|${to}&de=aavaaz-clinical@demo.com`;

    const response = await fetch(url, {
      signal: AbortSignal.timeout(3000), // 3s timeout — fail fast
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();

    if (data.responseStatus === 200 && data.responseData) {
      let translated = data.responseData.translatedText;
      translated = restoreGlossary(translated);

      // Cache result
      if (TRANSLATION_CACHE.size >= CACHE_MAX) {
        // Evict oldest entry
        const firstKey = TRANSLATION_CACHE.keys().next().value;
        TRANSLATION_CACHE.delete(firstKey);
      }
      TRANSLATION_CACHE.set(cacheKey, translated);

      return translated;
    }

    throw new Error('Translation API returned invalid response');
  } catch (err) {
    // Fallback: return original with marker
    console.error(`[Worker] Translation error: ${err.message}`);
    return `[translation pending] ${text}`;
  }
}

// Listen for messages from main thread
parentPort.on('message', async (msg) => {
  if (msg.type === 'translate') {
    const startTime = Date.now();
    const translated = await translateText(msg.text, msg.sourceLang, msg.targetLang);
    const latencyMs = Date.now() - startTime;

    parentPort.postMessage({
      type: 'translation_result',
      id: msg.id,
      original: msg.text,
      translated,
      sourceLang: msg.sourceLang,
      targetLang: msg.targetLang,
      latencyMs,
      fromRole: msg.fromRole,
    });
  }

  if (msg.type === 'prewarm') {
    // Pre-warm: translate a dummy phrase to init connection
    await translateText('hello', 'en', 'es');
    await translateText('hola', 'es', 'en');
    parentPort.postMessage({ type: 'prewarm_done' });
  }
});
